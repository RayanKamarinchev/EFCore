﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarDealer.Data
{
    public class Config
    {
        public const string ConnectionString = "Server=DESKTOP-7QAPP3E\\SQLEXPRESS;Database=CarDealer;Trusted_Connection=True;";
    }
}
