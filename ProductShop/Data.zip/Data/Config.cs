﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProductShop.Data
{
    public static class Config
    {
        public const string ConnectionString =
            @"Server=DESKTOP-7QAPP3E\SQLEXPRESS;Database=ProductShop;Integrated Security=True";
    }
}
