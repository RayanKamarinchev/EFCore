﻿using System;
using System.Linq;
using System.Text;
using BookShop.Models.Enums;

namespace BookShop
{
    using Data;
    using Initializer;

    public class StartUp
    {
        public static void Main()
        {
            var db = new BookShopContext();
            string command = Console.ReadLine();
            //DbInitializer.ResetDatabase(db);

            //Console.WriteLine(GetBooksByAgeRestriction(db, command));

            //Console.WriteLine(GetGoldenBooks(db));
            //Console.WriteLine(GetBooksByPrice(db));
            //int year = int.Parse(Console.ReadLine());
            //Console.WriteLine(GetBooksNotReleasedIn(db, year));
            //Console.WriteLine(GetBooksByCategory(db, command));
            //Console.WriteLine(GetBooksReleasedBefore(db, command));
            //Console.WriteLine(GetAuthorNamesEndingIn(db, command));
            Console.WriteLine(GetBookTitlesContaining(db, command));
            //Console.WriteLine(GetBooksByAuthor(db, command));
        }

        public static string GetBooksByAgeRestriction(BookShopContext context, string command)
        {
            StringBuilder sb = new StringBuilder();
            AgeRestriction ageRestriction;
            bool succes = Enum.TryParse(command, true, out ageRestriction);
            context.Books
                   .Where(b => b.AgeRestriction == ageRestriction)
                   .OrderBy(b => b.Title)
                   .Select(b => b.Title)
                   .ToList()
                   .ForEach(b => sb.AppendLine(b));
            return sb.ToString().TrimEnd();
        }

        public static string GetGoldenBooks(BookShopContext context)
        {
            StringBuilder sb = new StringBuilder();
            context.Books
                   .Where(b => b.Copies < 5000 && b.EditionType == EditionType.Gold)
                   .OrderBy(b => b.BookId)
                   .Select(b => b.Title)
                   .ToList()
                   .ForEach(b => sb.AppendLine(b));
            return sb.ToString().TrimEnd();
        }

        public static string GetBooksByPrice(BookShopContext context)
        {
            StringBuilder sb = new StringBuilder();
            context.Books
                   .Where(b => b.Price > 40)
                   .OrderByDescending(b => b.Price)
                   .Select(b => $"{b.Title} - ${b.Price:f2}")
                   .ToList()
                   .ForEach(b => sb.AppendLine(b));
            return sb.ToString().TrimEnd();
        }

        public static string GetBooksNotReleasedIn(BookShopContext context, int year)
        {
            StringBuilder sb = new StringBuilder();
            context.Books
                   .Where(b => b.ReleaseDate.Value.Year != year)
                   .OrderBy(b => b.BookId)
                   .Select(b => b.Title)
                   .ToList()
                   .ForEach(b => sb.AppendLine(b));
            return sb.ToString().TrimEnd();
        }

        public static string GetBooksByCategory(BookShopContext context, string input)
        {
            StringBuilder sb = new StringBuilder();
            string[] categories = input.Split(" ");
            context.Books
                   .Where(b => b.BookCategories.Any(item => categories.ToList().Contains(item.Category.Name)))
                   .OrderBy(b => b.Title)
                   .Select(b => b.Title)
                   .ToList()
                   .ForEach(b => sb.AppendLine(b));
            return sb.ToString().TrimEnd();
        }

        public static string GetBooksReleasedBefore(BookShopContext context, string date)
        {
            StringBuilder sb = new StringBuilder();
            DateTime st = DateTime.ParseExact(date, "dd-MM-yyyy", System.Globalization.CultureInfo.InvariantCulture);
            context.Books
                   .Where(b => b.ReleaseDate.Value < st)
                   .OrderByDescending(b=>b.ReleaseDate)
                   .Select(b => $"{b.Title} - {b.EditionType.ToString()} - ${b.Price:f2}")
                   .ToList()
                   .ForEach(b=>sb.AppendLine(b));
            return sb.ToString().TrimEnd();
        }

        public static string GetAuthorNamesEndingIn(BookShopContext context, string input)
        {
            StringBuilder sb = new StringBuilder();
            context.Authors
                   .Where(a=>a.FirstName.EndsWith(input))
                   .Select(a=>a.FirstName + " " + a.LastName)
                   .ToList()
                   .ForEach(a=>sb.AppendLine(a));
            return sb.ToString().TrimEnd();
        }

        public static string GetBooksByAuthor(BookShopContext context, string input)
        {
            StringBuilder sb = new StringBuilder();
            context.Books
                   .Where(b=>b.Author.LastName.StartsWith(input))
                   .OrderBy(b=>b.BookId)
                   .Select(b=>$"{b.Title} ({b.Author.FirstName} {b.Author.LastName})")
                   .ToList()
                   .ForEach(b=>sb.AppendLine(b));
            return sb.ToString().TrimEnd();
        }

        public static string GetBookTitlesContaining(BookShopContext context, string input)
        {
            StringBuilder sb= new StringBuilder();
            context.Books
                   .Where(b => b.Title.Contains(input))
                   .Select(b=>b.Title)
                   .ToList()
                   .ForEach(b=>sb.AppendLine(b));
            return sb.ToString().TrimEnd();
        }


    }
}
