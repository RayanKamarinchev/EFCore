﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MusicHub.Data.Models
{
    public enum Genre
    {
        Blues,
        Rap,
        PopMusic,
        Rock,
        Jazz
    }
}