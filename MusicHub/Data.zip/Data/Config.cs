﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MusicHub.Data
{
    public class Config
    {
        public static string ConnectionString =
            @"Server=DESKTOP-7QAPP3E\SQLEXPRESS;Database=MusicHub;Trusted_Connection=True";
    }
}
